WIDTH = 240
HEIGHT = 240
CAPTION = "This is an example of images in pyxel"

MARIO_X = 16
MARIO_Y = 216

LIVES = 3
LIVES_X=0
LOVES_Y=0

KONG_X = 0
KONG_Y = 0

PETRA_X = 80
PETRA_Y = 0


FLOOR_X = 0
FLOOR_Y = 231


LADDER_X = 0
LADDER_Y = 0


BARREL_X = 41
BARREL_Y = 17

BARRILES_X = 0
BARRILES_Y = 42

PLATFORM_X = 0
PLATFORM_Y = 151

POINTS = 0
